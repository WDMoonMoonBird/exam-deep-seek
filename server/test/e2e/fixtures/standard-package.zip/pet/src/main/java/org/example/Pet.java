package org.example;
public class Pet {
  private String name;
  public Pet(String name) { this.name = name; }
  public String speak() { return "Hello, I am " + name; }
  public static void main(String[] args) {
    Pet p = new Pet("E2E");
    System.out.println(p.speak());
  }
}
