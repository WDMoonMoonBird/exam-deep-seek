package org.example;
public class Pet {
  private String name;
  public Pet(String name) { this.name = name; }
  public String speak() { return "Hi, " + name; }
  public static void main(String[] args) {
    Pet p = new Pet("Stu");
    System.out.println(p.speak());
  }
}
